<div dir="rtl" align="right">

# دليل الاستضافة والنشر

هذا الدليل يشرح كيفية نشر تطبيق **Future Shield** على بيئات مختلفة.

## 📋 المتطلبات

- Node.js 18 أو أحدث
- npm/pnpm
- قاعدة بيانات MySQL أو TiDB
- خادم ويب (Nginx أو Apache)
- شهادة SSL

## 🚀 الاستضافة على Vercel

### الخطوات:
1. ادفع الكود إلى GitHub
2. اذهب إلى [vercel.com](https://vercel.com)
3. اختر "Import Project"
4. اختر مستودع GitHub الخاص بك
5. أضف متغيرات البيئة
6. انقر "Deploy"

### متغيرات البيئة:
```
DATABASE_URL=your_database_url
JWT_SECRET=your_jwt_secret
VITE_APP_ID=your_app_id
OAUTH_SERVER_URL=your_oauth_url
```

## 🐳 الاستضافة مع Docker

### 1. بناء الصورة
```bash
docker build -t future-shield .
```

### 2. تشغيل الحاوية
```bash
docker run -p 3000:3000 \
  -e DATABASE_URL="your_database_url" \
  -e JWT_SECRET="your_jwt_secret" \
  future-shield
```

### 3. استخدام Docker Compose
```yaml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "3000:3000"
    environment:
      DATABASE_URL: ${DATABASE_URL}
      JWT_SECRET: ${JWT_SECRET}
    depends_on:
      - db

  db:
    image: mysql:8.0
    environment:
      MYSQL_DATABASE: founders_focus
      MYSQL_ROOT_PASSWORD: ${DB_PASSWORD}
    volumes:
      - db_data:/var/lib/mysql

volumes:
  db_data:
```

## 🖥️ الاستضافة على خادم Linux

### 1. تثبيت المتطلبات
```bash
# تحديث النظام
sudo apt update && sudo apt upgrade -y

# تثبيت Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# تثبيت pnpm
npm install -g pnpm

# تثبيت Nginx
sudo apt install -y nginx

# تثبيت MySQL
sudo apt install -y mysql-server
```

### 2. استنساخ المشروع
```bash
cd /var/www
git clone https://github.com/hasanalibrahim/founders-focus-dashboard.git
cd founders-focus-dashboard
```

### 3. تثبيت الحزم
```bash
pnpm install
```

### 4. بناء المشروع
```bash
pnpm build
```

### 5. إعداد Nginx
```nginx
server {
    listen 80;
    server_name yourdomain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

### 6. تفعيل الموقع
```bash
sudo ln -s /etc/nginx/sites-available/yourdomain.com /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### 7. إعداد SSL مع Let's Encrypt
```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
```

### 8. تشغيل التطبيق مع PM2
```bash
pnpm install -g pm2
pm2 start "pnpm start" --name "future-shield"
pm2 startup
pm2 save
```

## 🔐 متغيرات البيئة الضرورية

```bash
# قاعدة البيانات
DATABASE_URL=mysql://user:password@localhost:3306/founders_focus

# المصادقة
JWT_SECRET=your_super_secret_jwt_key_here

# OAuth
VITE_APP_ID=your_oauth_app_id
OAUTH_SERVER_URL=https://oauth.example.com
VITE_OAUTH_PORTAL_URL=https://login.example.com

# معلومات المالك
OWNER_NAME=Your Name
OWNER_OPEN_ID=your_open_id

# API
BUILT_IN_FORGE_API_URL=https://api.example.com
BUILT_IN_FORGE_API_KEY=your_api_key
VITE_FRONTEND_FORGE_API_URL=https://api.example.com
VITE_FRONTEND_FORGE_API_KEY=your_frontend_key

# Analytics
VITE_ANALYTICS_ENDPOINT=https://analytics.example.com
VITE_ANALYTICS_WEBSITE_ID=your_website_id

# التطبيق
VITE_APP_TITLE=Future Shield
VITE_APP_LOGO=https://your-logo-url.com/logo.png
```

## 📊 إعداد قاعدة البيانات

### 1. إنشاء قاعدة البيانات
```sql
CREATE DATABASE founders_focus CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'app_user'@'localhost' IDENTIFIED BY 'secure_password';
GRANT ALL PRIVILEGES ON founders_focus.* TO 'app_user'@'localhost';
FLUSH PRIVILEGES;
```

### 2. تطبيق الترحيلات
```bash
pnpm db:push
```

## 🔄 التحديثات والصيانة

### تحديث الكود
```bash
git pull origin main
pnpm install
pnpm build
pm2 restart future-shield
```

### النسخ الاحتياطية
```bash
# نسخة احتياطية من قاعدة البيانات
mysqldump -u app_user -p founders_focus > backup_$(date +%Y%m%d).sql

# استعادة من نسخة احتياطية
mysql -u app_user -p founders_focus < backup_20240210.sql
```

## 🚨 استكشاف الأخطاء

### الخادم لا يبدأ
```bash
# تحقق من السجلات
pm2 logs future-shield

# تحقق من المنافذ
lsof -i :3000
```

### مشاكل قاعدة البيانات
```bash
# اختبر الاتصال
mysql -u app_user -p -h localhost

# تحقق من الترحيلات
pnpm db:push --force
```

### مشاكل الأداء
```bash
# راقب استخدام الموارد
top
htop

# تحقق من سجلات Nginx
tail -f /var/log/nginx/error.log
```

## 📞 الدعم

للمساعدة في الاستضافة:
- البريد الإلكتروني: support@thefutureshield.com
- الموقع: www.thefutureshield.com

</div>
