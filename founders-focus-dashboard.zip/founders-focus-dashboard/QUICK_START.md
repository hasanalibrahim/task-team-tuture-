<div dir="rtl" align="right">

# 🚀 دليل البدء السريع

هذا الدليل سيساعدك على تشغيل **Future Shield** في دقائق معدودة.

## ⚡ البدء في 5 دقائق

### الخطوة 1: استنساخ المشروع
```bash
git clone https://github.com/hasanalibrahim/founders-focus-dashboard.git
cd founders-focus-dashboard
```

### الخطوة 2: تثبيت الحزم
```bash
pnpm install
```

### الخطوة 3: إعداد قاعدة البيانات
```bash
# نسخ ملف البيئة
cp .env.example .env.local

# تحديث DATABASE_URL في .env.local بمعلومات قاعدة البيانات لديك

# تطبيق الترحيلات
pnpm db:push
```

### الخطوة 4: تشغيل التطبيق
```bash
pnpm dev
```

افتح المتصفح على `http://localhost:3000` 🎉

---

## 🐳 البدء مع Docker

### الخطوة 1: استنساخ المشروع
```bash
git clone https://github.com/hasanalibrahim/founders-focus-dashboard.git
cd founders-focus-dashboard
```

### الخطوة 2: إنشاء ملف .env
```bash
cp .env.example .env.local
```

### الخطوة 3: تشغيل Docker Compose
```bash
docker-compose up -d
```

### الخطوة 4: الانتظار لتهيئة قاعدة البيانات
```bash
# تطبيق الترحيلات
docker-compose exec app pnpm db:push
```

افتح المتصفح على `http://localhost:3000` 🎉

---

## 📝 الخطوات التالية

### 1. إنشاء حسابك
- اذهب إلى الصفحة الرئيسية
- انقر "دخول" أو "ابدأ الآن"
- أكمل عملية التسجيل

### 2. إنشاء مشروعك الأول
- انقر على "المشاريع" من الشريط الجانبي
- انقر "مشروع جديد"
- أدخل اسم المشروع والوصف
- انقر "إنشاء"

### 3. تحديد الأهداف
- انقر على "الأهداف"
- انقر "هدف جديد"
- اربط الهدف بمشاريعك
- حدد الإطار الزمني

### 4. حفظ الأفكار
- انقر على "الأفكار"
- انقر "فكرة جديدة"
- احفظ أفكارك دون التشتت

---

## 🔧 الأوامر المهمة

```bash
# تشغيل الخادم الإنمائي
pnpm dev

# بناء المشروع
pnpm build

# تشغيل الاختبارات
pnpm test

# التحقق من الأخطاء
pnpm check

# تنسيق الكود
pnpm format

# تطبيق ترحيلات قاعدة البيانات
pnpm db:push

# عرض سجلات Docker
docker-compose logs -f app

# إيقاف Docker
docker-compose down
```

---

## 🆘 استكشاف الأخطاء الشائعة

### خطأ: "Cannot find module"
```bash
# حل: أعد تثبيت الحزم
rm -rf node_modules pnpm-lock.yaml
pnpm install
```

### خطأ: "Database connection failed"
```bash
# تحقق من:
# 1. DATABASE_URL صحيح في .env.local
# 2. قاعدة البيانات تعمل
# 3. بيانات المستخدم صحيحة
```

### خطأ: "Port 3000 is already in use"
```bash
# استخدم منفذ مختلف
PORT=3001 pnpm dev
```

### خطأ: "OAuth configuration missing"
```bash
# تأكد من وجود:
# - VITE_APP_ID
# - OAUTH_SERVER_URL
# - VITE_OAUTH_PORTAL_URL
```

---

## 📚 الموارد الإضافية

- 📖 [التوثيق الكامل](./README.md)
- 🚀 [دليل الاستضافة](./DEPLOYMENT.md)
- 🤝 [دليل المساهمة](./CONTRIBUTING.md)
- 🐛 [الإبلاغ عن الأخطاء](https://github.com/hasanalibrahim/founders-focus-dashboard/issues)

---

## 💬 الدعم

هل تواجه مشكلة؟
- 📧 البريد الإلكتروني: support@thefutureshield.com
- 🌐 الموقع: www.thefutureshield.com
- 💬 GitHub Issues: [اسأل هنا](https://github.com/hasanalibrahim/founders-focus-dashboard/issues)

---

**استمتع بـ Future Shield! 🎉**

</div>
