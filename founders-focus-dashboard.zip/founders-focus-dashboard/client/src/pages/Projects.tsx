import React, { useState } from 'react';
import { trpc } from '@/lib/trpc';
import DashboardLayoutAr from '@/components/DashboardLayoutAr';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Edit2, Trash2, CheckCircle, Clock, Pause } from 'lucide-react';
import { toast } from 'sonner';

export default function Projects() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({ title: '', description: '' });

  const { data: projects = [], isLoading, refetch } = trpc.projects.list.useQuery();
  const createMutation = trpc.projects.create.useMutation();
  const updateMutation = trpc.projects.update.useMutation();
  const deleteMutation = trpc.projects.delete.useMutation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (editingId) {
        await updateMutation.mutateAsync({
          id: editingId,
          title: formData.title,
          description: formData.description,
        });
        toast.success('تم تحديث المشروع بنجاح');
      } else {
        await createMutation.mutateAsync({
          title: formData.title,
          description: formData.description,
        });
        toast.success('تم إنشاء المشروع بنجاح');
      }
      
      setFormData({ title: '', description: '' });
      setEditingId(null);
      setIsDialogOpen(false);
      refetch();
    } catch (error) {
      toast.error('حدث خطأ ما');
    }
  };

  const handleDelete = async (id: number) => {
    if (confirm('هل أنت متأكد من حذف هذا المشروع؟')) {
      try {
        await deleteMutation.mutateAsync({ id });
        toast.success('تم حذف المشروع بنجاح');
        refetch();
      } catch (error) {
        toast.error('فشل حذف المشروع');
      }
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="text-green-500" size={20} />;
      case 'paused':
        return <Pause className="text-yellow-500" size={20} />;
      default:
        return <Clock className="text-blue-500" size={20} />;
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'completed':
        return 'مكتمل';
      case 'paused':
        return 'متوقف';
      default:
        return 'قيد التنفيذ';
    }
  };

  if (isLoading) {
    return (
      <DashboardLayoutAr title="المشاريع">
        <div className="flex items-center justify-center h-96">
          <p className="text-muted-foreground">جاري التحميل...</p>
        </div>
      </DashboardLayoutAr>
    );
  }

  return (
    <DashboardLayoutAr title="المشاريع">
      <div className="space-y-6">
        {/* Header with Add Button */}
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">مشاريعي</h1>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus size={20} />
                مشروع جديد
              </Button>
            </DialogTrigger>
            <DialogContent dir="rtl">
              <DialogHeader>
                <DialogTitle>{editingId ? 'تعديل المشروع' : 'إنشاء مشروع جديد'}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">عنوان المشروع</label>
                  <Input
                    placeholder="أدخل عنوان المشروع"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">الوصف</label>
                  <Textarea
                    placeholder="أدخل وصف المشروع"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  />
                </div>
                <div className="flex gap-2 justify-end">
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    إلغاء
                  </Button>
                  <Button type="submit">
                    {editingId ? 'تحديث' : 'إنشاء'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Projects Grid */}
        {projects.length === 0 ? (
          <Card className="p-12 text-center">
            <p className="text-muted-foreground mb-4">لا توجد مشاريع حالياً</p>
            <p className="text-sm text-muted-foreground">ابدأ بإنشاء مشروع جديد لتتبع عملك</p>
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {projects.map((project: any) => (
              <Card key={project.id} className="p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-2">
                    {getStatusIcon(project.status)}
                    <span className="text-sm font-medium text-muted-foreground">
                      {getStatusLabel(project.status)}
                    </span>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        setFormData({ title: project.title, description: project.description || '' });
                        setEditingId(project.id);
                        setIsDialogOpen(true);
                      }}
                      className="p-2 hover:bg-muted rounded-lg transition-colors"
                    >
                      <Edit2 size={18} />
                    </button>
                    <button
                      onClick={() => handleDelete(project.id)}
                      className="p-2 hover:bg-red-100 dark:hover:bg-red-900 rounded-lg transition-colors text-red-500"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>

                <h3 className="text-lg font-bold mb-2">{project.title}</h3>
                {project.description && (
                  <p className="text-sm text-muted-foreground mb-4">{project.description}</p>
                )}

                {/* Progress Bar */}
                <div className="mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-medium">التقدم</span>
                    <span className="text-xs font-bold text-accent">{project.progressPercentage}%</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div
                      className="bg-accent h-2 rounded-full transition-all"
                      style={{ width: `${project.progressPercentage}%` }}
                    />
                  </div>
                </div>

                {/* Priority Badge */}
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">الأولوية</span>
                  <span className="px-2 py-1 bg-muted rounded-full font-medium">
                    {project.priority}/5
                  </span>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </DashboardLayoutAr>
  );
}
