import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, ArrowRight, Target, Lightbulb, Clock, BarChart3, Briefcase } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import DashboardLayoutAr from "@/components/DashboardLayoutAr";
import { trpc } from "@/lib/trpc";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const projectsQuery = trpc.projects.list.useQuery();
  const goalsQuery = trpc.goals.list.useQuery();
  const projects = isAuthenticated ? projectsQuery.data || [] : [];
  const goals = isAuthenticated ? goalsQuery.data || [] : [];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="animate-spin" size={40} />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-accent/10 to-background" dir="rtl">
        {/* Navigation */}
        <nav className="bg-card border-b border-border sticky top-0 z-50">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <h1 className="text-2xl font-bold text-accent">مؤسس فوكاس</h1>
            <Button asChild>
              <a href={getLoginUrl()}>دخول</a>
            </Button>
          </div>
        </nav>

        {/* Hero Section */}
        <section className="container mx-auto px-4 py-20">
          <div className="max-w-3xl mx-auto text-center space-y-6">
            <h2 className="text-5xl font-bold text-foreground leading-tight">
              إدارة مشاريعك بذكاء وتركيز
            </h2>
            <p className="text-xl text-muted-foreground">
              منصة متكاملة لإدارة المشاريع والأهداف والوقت، مصممة خصيصاً للمؤسسين الناجحين
            </p>
            <div className="flex gap-4 justify-center pt-4">
              <Button asChild size="lg" className="gap-2">
                <a href={getLoginUrl()}>
                  ابدأ الآن
                  <ArrowRight size={20} />
                </a>
              </Button>
              <Button asChild size="lg" variant="outline">
                <a href="#features">تعرف على المزيد</a>
              </Button>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section id="features" className="bg-card border-t border-border py-20">
          <div className="container mx-auto px-4">
            <h3 className="text-3xl font-bold text-center mb-12">المميزات الرئيسية</h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card className="p-6 hover:shadow-lg transition-shadow">
                <Briefcase className="text-accent mb-4" size={32} />
                <h4 className="text-lg font-bold mb-2">إدارة المشاريع</h4>
                <p className="text-muted-foreground">
                  تتبع مشاريعك بسهولة مع تحديثات التقدم والحالات المختلفة
                </p>
              </Card>
              <Card className="p-6 hover:shadow-lg transition-shadow">
                <Target className="text-accent mb-4" size={32} />
                <h4 className="text-lg font-bold mb-2">الأهداف طويلة المدى</h4>
                <p className="text-muted-foreground">
                  ربط أهدافك بمشاريعك للبقاء على المسار الصحيح
                </p>
              </Card>
              <Card className="p-6 hover:shadow-lg transition-shadow">
                <Lightbulb className="text-accent mb-4" size={32} />
                <h4 className="text-lg font-bold mb-2">مستودع الأفكار</h4>
                <p className="text-muted-foreground">
                  احفظ أفكارك الجديدة دون التشتت عن عملك الحالي
                </p>
              </Card>
              <Card className="p-6 hover:shadow-lg transition-shadow">
                <Clock className="text-accent mb-4" size={32} />
                <h4 className="text-lg font-bold mb-2">تتبع الوقت</h4>
                <p className="text-muted-foreground">
                  قس إنتاجيتك وحسّن من استخدام وقتك
                </p>
              </Card>
              <Card className="p-6 hover:shadow-lg transition-shadow">
                <BarChart3 className="text-accent mb-4" size={32} />
                <h4 className="text-lg font-bold mb-2">التحليلات والتقارير</h4>
                <p className="text-muted-foreground">
                  احصل على رؤى عميقة عن أدائك وتقدمك
                </p>
              </Card>
              <Card className="p-6 hover:shadow-lg transition-shadow">
                <Briefcase className="text-accent mb-4" size={32} />
                <h4 className="text-lg font-bold mb-2">إدارة الشركة</h4>
                <p className="text-muted-foreground">
                  تابع المهام الإدارية والمالية والعملاء
                </p>
              </Card>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20">
          <div className="container mx-auto px-4 text-center space-y-6">
            <h3 className="text-3xl font-bold">جاهز للبدء؟</h3>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              انضم إلى آلاف المؤسسين الذين يستخدمون مؤسس فوكاس لإدارة مشاريعهم بكفاءة
            </p>
            <Button asChild size="lg" className="gap-2">
              <a href={getLoginUrl()}>
                ابدأ مجاناً الآن
                <ArrowRight size={20} />
              </a>
            </Button>
          </div>
        </section>
      </div>
    );
  }

  return (
    <DashboardLayoutAr title="لوحة التحكم">
      <div className="space-y-8">
        {/* Welcome Section */}
        <div className="bg-gradient-to-r from-accent/10 to-accent/5 rounded-lg p-6 border border-accent/20">
          <h2 className="text-2xl font-bold mb-2">أهلاً وسهلاً، {user?.name}</h2>
          <p className="text-muted-foreground">
            مرحباً بك في لوحة التحكم. إليك ملخص حالتك الحالية
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-4">
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">المشاريع النشطة</p>
                <p className="text-3xl font-bold">{projects.filter((p: any) => p.status === 'in_progress').length}</p>
              </div>
              <Briefcase className="text-accent opacity-50" size={32} />
            </div>
          </Card>
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">الأهداف النشطة</p>
                <p className="text-3xl font-bold">{goals.filter((g: any) => g.status === 'active').length}</p>
              </div>
              <Target className="text-accent opacity-50" size={32} />
            </div>
          </Card>
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">المشاريع المكتملة</p>
                <p className="text-3xl font-bold">{projects.filter((p: any) => p.status === 'completed').length}</p>
              </div>
              <Briefcase className="text-green-500 opacity-50" size={32} />
            </div>
          </Card>
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">معدل الإنجاز</p>
                <p className="text-3xl font-bold">
                  {projects.length > 0
                    ? Math.round(
                        (projects.filter((p: any) => p.status === 'completed').length / projects.length) * 100
                      )
                    : 0}
                  %
                </p>
              </div>
              <BarChart3 className="text-accent opacity-50" size={32} />
            </div>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-3 gap-4">
          <Button
            variant="outline"
            className="h-auto p-6 flex flex-col items-start gap-2"
            onClick={() => navigate('/projects')}
          >
            <Briefcase size={24} />
            <span>إدارة المشاريع</span>
          </Button>
          <Button
            variant="outline"
            className="h-auto p-6 flex flex-col items-start gap-2"
            onClick={() => navigate('/goals')}
          >
            <Target size={24} />
            <span>تحديد الأهداف</span>
          </Button>
          <Button
            variant="outline"
            className="h-auto p-6 flex flex-col items-start gap-2"
            onClick={() => navigate('/ideas')}
          >
            <Lightbulb size={24} />
            <span>مستودع الأفكار</span>
          </Button>
        </div>

        {/* Recent Projects */}
        <div>
          <h3 className="text-lg font-bold mb-4">المشاريع الأخيرة</h3>
          {projects.length === 0 ? (
            <Card className="p-8 text-center">
              <p className="text-muted-foreground">لا توجد مشاريع حالياً</p>
            </Card>
          ) : (
            <div className="space-y-2">
              {projects.slice(0, 5).map((project: any) => (
                <Card key={project.id} className="p-4 flex items-center justify-between hover:bg-muted/50 transition-colors">
                  <div>
                    <p className="font-medium">{project.title}</p>
                    <p className="text-sm text-muted-foreground">{project.description}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-accent">{project.progressPercentage}%</p>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </DashboardLayoutAr>
  );
}
