# Founder's Focus Dashboard - Data Model

## Core Tables

### 1. Projects Table
```
projects:
  - id (PK)
  - userId (FK)
  - title (string)
  - description (text)
  - status (enum: in_progress, completed, paused)
  - progressPercentage (int: 0-100)
  - startDate (timestamp)
  - targetDate (timestamp)
  - completedDate (timestamp, nullable)
  - priority (int: 1-5)
  - createdAt (timestamp)
  - updatedAt (timestamp)
```

### 2. Goals Table
```
goals:
  - id (PK)
  - userId (FK)
  - title (string)
  - description (text)
  - timeframe (enum: short_term, medium_term, long_term)
  - targetDate (timestamp)
  - status (enum: active, completed, abandoned)
  - linkedProjectIds (json array)
  - createdAt (timestamp)
  - updatedAt (timestamp)
```

### 3. Ideas Table
```
ideas:
  - id (PK)
  - userId (FK)
  - title (string)
  - description (text)
  - category (string)
  - status (enum: parked, in_review, converted_to_project)
  - convertedProjectId (FK, nullable)
  - capturedAt (timestamp)
  - createdAt (timestamp)
  - updatedAt (timestamp)
```

### 4. Time Logs Table
```
timeLogs:
  - id (PK)
  - userId (FK)
  - projectId (FK)
  - duration (int: minutes)
  - startTime (timestamp)
  - endTime (timestamp)
  - description (string)
  - date (date)
  - createdAt (timestamp)
```

### 5. Tasks Table
```
tasks:
  - id (PK)
  - userId (FK)
  - projectId (FK, nullable)
  - title (string)
  - description (text)
  - category (enum: legal, administrative, client, financial)
  - status (enum: pending, in_progress, completed)
  - dueDate (timestamp)
  - priority (int: 1-5)
  - assignedTo (string, nullable)
  - createdAt (timestamp)
  - updatedAt (timestamp)
```

### 6. Reminders Table
```
reminders:
  - id (PK)
  - userId (FK)
  - taskId (FK)
  - type (enum: overdue, upcoming, milestone)
  - dueDate (timestamp)
  - reminderDate (timestamp)
  - status (enum: pending, sent, dismissed)
  - createdAt (timestamp)
```

### 7. Weekly Priorities Table
```
weeklyPriorities:
  - id (PK)
  - userId (FK)
  - weekStartDate (date)
  - projectIds (json array, max 3)
  - notes (text)
  - createdAt (timestamp)
  - updatedAt (timestamp)
```

### 8. Financial Records Table
```
financialRecords:
  - id (PK)
  - userId (FK)
  - projectId (FK, nullable)
  - type (enum: revenue, expense)
  - amount (decimal)
  - category (string)
  - description (text)
  - date (date)
  - createdAt (timestamp)
```

### 9. Reports Table
```
reports:
  - id (PK)
  - userId (FK)
  - type (enum: weekly, monthly)
  - period (string: YYYY-WW or YYYY-MM)
  - content (json)
  - generatedAt (timestamp)
  - sentAt (timestamp, nullable)
  - createdAt (timestamp)
```

### 10. AI Conversations Table
```
aiConversations:
  - id (PK)
  - userId (FK)
  - messages (json array)
  - context (json: project status, goals, etc.)
  - createdAt (timestamp)
  - updatedAt (timestamp)
```

### 11. Clients Table
```
clients:
  - id (PK)
  - userId (FK)
  - name (string)
  - email (string)
  - phone (string)
  - company (string)
  - address (text)
  - notes (text)
  - createdAt (timestamp)
  - updatedAt (timestamp)
```

### 12. Resources Table
```
resources:
  - id (PK)
  - title (string)
  - category (enum: legal, tax, marketing, operations)
  - content (text)
  - url (string, nullable)
  - forNewFounders (boolean)
  - usSpecific (boolean)
  - createdAt (timestamp)
```

## Relationships

- **Projects ↔ Goals**: Many-to-Many (goals can link to multiple projects)
- **Projects ↔ Time Logs**: One-to-Many
- **Projects ↔ Tasks**: One-to-Many
- **Tasks ↔ Reminders**: One-to-Many
- **Users ↔ All Tables**: One-to-Many

## Key Constraints

1. **3-Project Limit**: Weekly priorities can have maximum 3 active projects
2. **Status Transitions**: Projects can only transition between valid states
3. **Time Log Validation**: End time must be after start time
4. **Financial Records**: Amount must be positive
5. **Goal Linking**: Goals can link to multiple projects but projects should align with goals

## Indexes for Performance

- `projects(userId, status)`
- `timeLogs(userId, date)`
- `tasks(userId, dueDate, status)`
- `goals(userId, status)`
- `weeklyPriorities(userId, weekStartDate)`
- `financialRecords(userId, date)`
