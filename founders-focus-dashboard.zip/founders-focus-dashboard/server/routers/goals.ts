import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { getUserGoals, getDb } from "../db";
import { goals } from "../../drizzle/schema";
import { eq } from "drizzle-orm";

export const goalsRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    return await getUserGoals(ctx.user.id);
  }),

  create: protectedProcedure
    .input(
      z.object({
        title: z.string().min(1),
        description: z.string().optional(),
        timeframe: z.enum(["short_term", "medium_term", "long_term"]).default("medium_term"),
        targetDate: z.date().optional(),
        linkedProjectIds: z.array(z.number()).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      
      const result = await db.insert(goals).values({
        userId: ctx.user.id,
        title: input.title,
        description: input.description,
        timeframe: input.timeframe,
        targetDate: input.targetDate,
        linkedProjectIds: input.linkedProjectIds || [],
        status: "active",
      });
      
      return result;
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        status: z.enum(["active", "completed", "abandoned"]).optional(),
        targetDate: z.date().optional(),
        linkedProjectIds: z.array(z.number()).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      
      const updateData: Record<string, any> = {};
      if (input.title !== undefined) updateData.title = input.title;
      if (input.description !== undefined) updateData.description = input.description;
      if (input.status !== undefined) updateData.status = input.status;
      if (input.targetDate !== undefined) updateData.targetDate = input.targetDate;
      if (input.linkedProjectIds !== undefined) updateData.linkedProjectIds = input.linkedProjectIds;
      
      await db.update(goals).set(updateData).where(eq(goals.id, input.id));
      
      return { success: true };
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      
      await db.delete(goals).where(eq(goals.id, input.id));
      return { success: true };
    }),
});
