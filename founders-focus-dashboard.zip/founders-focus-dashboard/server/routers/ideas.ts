import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { getUserIdeas, getDb } from "../db";
import { ideas } from "../../drizzle/schema";
import { eq } from "drizzle-orm";

export const ideasRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    return await getUserIdeas(ctx.user.id);
  }),

  create: protectedProcedure
    .input(
      z.object({
        title: z.string().min(1),
        description: z.string().optional(),
        category: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      
      const result = await db.insert(ideas).values({
        userId: ctx.user.id,
        title: input.title,
        description: input.description,
        category: input.category,
        status: "parked",
      });
      
      return result;
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        category: z.string().optional(),
        status: z.enum(["parked", "in_review", "converted_to_project"]).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      
      const updateData: Record<string, any> = {};
      if (input.title !== undefined) updateData.title = input.title;
      if (input.description !== undefined) updateData.description = input.description;
      if (input.category !== undefined) updateData.category = input.category;
      if (input.status !== undefined) updateData.status = input.status;
      
      await db.update(ideas).set(updateData).where(eq(ideas.id, input.id));
      
      return { success: true };
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      
      await db.delete(ideas).where(eq(ideas.id, input.id));
      return { success: true };
    }),
});
