import { describe, it, expect, beforeEach } from "vitest";
import { goalsRouter } from "./goals";
import type { TrpcContext } from "../_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createMockContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("goalsRouter", () => {
  let ctx: TrpcContext;

  beforeEach(() => {
    ctx = createMockContext();
  });

  describe("list", () => {
    it("should return empty list for new user", async () => {
      const caller = goalsRouter.createCaller(ctx);
      const result = await caller.list();
      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe("create", () => {
    it("should create a goal with valid input", async () => {
      const caller = goalsRouter.createCaller(ctx);
      const result = await caller.create({
        title: "Learn TypeScript",
        description: "Master TypeScript fundamentals",
        timeframe: "short_term",
      });
      expect(result).toBeDefined();
    });

    it("should set default timeframe to medium_term", async () => {
      const caller = goalsRouter.createCaller(ctx);
      const result = await caller.create({
        title: "Build a SaaS",
      });
      expect(result).toBeDefined();
    });

    it("should link projects to goals", async () => {
      const caller = goalsRouter.createCaller(ctx);
      const result = await caller.create({
        title: "Complete Project X",
        linkedProjectIds: [1, 2, 3],
      });
      expect(result).toBeDefined();
    });
  });

  describe("update", () => {
    it("should update goal status to completed", async () => {
      const caller = goalsRouter.createCaller(ctx);
      const result = await caller.update({
        id: 1,
        status: "completed",
      });
      expect(result.success).toBe(true);
    });

    it("should update linked projects", async () => {
      const caller = goalsRouter.createCaller(ctx);
      const result = await caller.update({
        id: 1,
        linkedProjectIds: [4, 5],
      });
      expect(result.success).toBe(true);
    });
  });

  describe("delete", () => {
    it("should delete a goal", async () => {
      const caller = goalsRouter.createCaller(ctx);
      const result = await caller.delete({ id: 1 });
      expect(result.success).toBe(true);
    });
  });
});
