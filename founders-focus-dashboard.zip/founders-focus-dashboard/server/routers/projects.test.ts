import { describe, it, expect, beforeEach, vi } from "vitest";
import { projectsRouter } from "./projects";
import type { TrpcContext } from "../_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createMockContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("projectsRouter", () => {
  let ctx: TrpcContext;

  beforeEach(() => {
    ctx = createMockContext();
  });

  describe("list", () => {
    it("should return empty list for new user", async () => {
      const caller = projectsRouter.createCaller(ctx);
      const result = await caller.list();
      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe("create", () => {
    it("should create a project with valid input", async () => {
      const caller = projectsRouter.createCaller(ctx);
      const result = await caller.create({
        title: "Test Project",
        description: "A test project",
      });
      expect(result).toBeDefined();
    });

    it("should fail with empty title", async () => {
      const caller = projectsRouter.createCaller(ctx);
      try {
        await caller.create({
          title: "",
          description: "A test project",
        });
        expect.fail("Should have thrown an error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });

    it("should set default priority to 3", async () => {
      const caller = projectsRouter.createCaller(ctx);
      const result = await caller.create({
        title: "Test Project",
      });
      expect(result).toBeDefined();
    });
  });

  describe("update", () => {
    it("should update project status to completed", async () => {
      const caller = projectsRouter.createCaller(ctx);
      const result = await caller.update({
        id: 1,
        status: "completed",
      });
      expect(result.success).toBe(true);
    });

    it("should update progress percentage", async () => {
      const caller = projectsRouter.createCaller(ctx);
      const result = await caller.update({
        id: 1,
        progressPercentage: 50,
      });
      expect(result.success).toBe(true);
    });

    it("should reject invalid progress percentage", async () => {
      const caller = projectsRouter.createCaller(ctx);
      try {
        await caller.update({
          id: 1,
          progressPercentage: 150,
        });
        expect.fail("Should have thrown an error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });

  describe("delete", () => {
    it("should delete a project", async () => {
      const caller = projectsRouter.createCaller(ctx);
      const result = await caller.delete({ id: 1 });
      expect(result.success).toBe(true);
    });
  });
});
