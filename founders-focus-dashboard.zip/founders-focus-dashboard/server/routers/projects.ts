import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { getUserProjects, createProject, getDb } from "../db";
import { projects } from "../../drizzle/schema";
import { eq } from "drizzle-orm";

export const projectsRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    return await getUserProjects(ctx.user.id);
  }),

  create: protectedProcedure
    .input(
      z.object({
        title: z.string().min(1),
        description: z.string().optional(),
        targetDate: z.date().optional(),
        priority: z.number().min(1).max(5).default(3),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      
      const result = await db.insert(projects).values({
        userId: ctx.user.id,
        title: input.title,
        description: input.description,
        targetDate: input.targetDate,
        priority: input.priority,
        status: "in_progress",
        progressPercentage: 0,
      });
      
      return result;
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        status: z.enum(["in_progress", "completed", "paused"]).optional(),
        progressPercentage: z.number().min(0).max(100).optional(),
        targetDate: z.date().optional(),
        priority: z.number().min(1).max(5).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      
      const updateData: Record<string, any> = {};
      if (input.title !== undefined) updateData.title = input.title;
      if (input.description !== undefined) updateData.description = input.description;
      if (input.status !== undefined) {
        updateData.status = input.status;
        if (input.status === "completed") {
          updateData.completedDate = new Date();
          updateData.progressPercentage = 100;
        }
      }
      if (input.progressPercentage !== undefined) updateData.progressPercentage = input.progressPercentage;
      if (input.targetDate !== undefined) updateData.targetDate = input.targetDate;
      if (input.priority !== undefined) updateData.priority = input.priority;
      
      await db.update(projects).set(updateData).where(
        eq(projects.id, input.id)
      );
      
      return { success: true };
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      
      await db.delete(projects).where(eq(projects.id, input.id));
      return { success: true };
    }),
});
