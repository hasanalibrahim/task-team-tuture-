# Future Shield - منصة إدارة المشاريع والإنتاجية

<div dir="rtl" align="right">

![Future Shield Logo](https://private-us-east-1.manuscdn.com/sessionFile/5f1it7pzfYjWYYTMv8qyyb/sandbox/29HhYJ7fV7BEJ9QuBs9T3O_1770746016080_na1fn_ZnV0dXJlLXNoaWVsZC1sb2dv.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvNWYxaXQ3cHpmWWpXWVlUTXY4cXl5Yi9zYW5kYm94LzI5SGhZSjdmVjdCRUo5UXVCczlUM09fMTc3MDc0NjAxNjA4MF9uYTFmbl9ablYwZFhKbExYTm9hV1ZzWkMxc2IyZHYucG5nP3gtb3NzLXByb2Nlc3M9aW1hZ2UvcmVzaXplLHdfMTkyMCxoXzE5MjAvZm9ybWF0LHdlYnAvcXVhbGl0eSxxXzgwIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk4NzYxNjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=qPbIv0wOV4wOXxokQyXRoA6VAaFnf88U4jbi-yMMH-cwjKZvOuZr-jf2YMFd~ozA-TG53LM5goNlwUJJOlUEpG9l287Igg13b9Jvk9jGXDVjYgrORZ3zYDA-Gmltx8~xMbwEdgqDKZ8eM1rVj79LnQso5GP9DyiIeaCy6wcRRsX-JvLAaEam0PQ3RR97wSS-nx7H9Bw2NOaULvuZ0F8U4mU1-cRFaoItr6UlF6HowXNOPxDWVGUqyLTMwTWbgO5-mDA07kORCbUj1QaYeiNK-XR3cXoBGiCO8v5SUFlNjwTFwSDQTvCVGnwUHbLXjhkbdnLOiqza24VjTQ-KVwj-2Q__)

منصة احترافية وقوية لإدارة المشاريع والأهداف والوقت، مصممة خصيصاً للمؤسسين والقادة الذين يديرون عدة مشاريع في نفس الوقت.

## 🎯 المميزات الرئيسية

### 📊 إدارة المشاريع المتقدمة
- إنشاء وإدارة المشاريع مع تتبع التقدم المفصل
- ثلاث حالات للمشروع: قيد التنفيذ، مكتمل، متوقف
- تتبع نسبة التقدم لكل مشروع
- تحديد أولويات المشاريع (1-5)

### 🎯 إدارة الأهداف طويلة المدى
- ربط الأهداف بالمشاريع الحالية
- تصنيف الأهداف: قصيرة المدى، متوسطة المدى، طويلة المدى
- تتبع حالة الأهداف (نشط، مكتمل، مهجور)

### 💡 مستودع الأفكار
- حفظ الأفكار الجديدة دون التشتت عن العمل الحالي
- تنظيم الأفكار حسب الفئات
- تحويل الأفكار إلى مشاريع

### ⏱️ تتبع الوقت والإنتاجية
- تسجيل جلسات العمل لكل مشروع
- تقارير أسبوعية وشهرية للإنتاجية
- تحليل توزيع الوقت على المشاريع

### 📈 التحليلات والتقارير
- لوحة تحكم شاملة بالإحصائيات
- رسوم بيانية لتتبع التقدم
- تقارير شهرية آلية

### 🔔 نظام التذكيرات الذكي
- تنبيهات للمهام المتأخرة
- تذكيرات بالمواعيد النهائية
- إشعارات مخصصة

### 🏢 إدارة الشركة
- تتبع المهام الإدارية والقانونية
- إدارة العملاء والمشاريع
- تتبع الإيرادات والمصروفات

### 🤖 المساعد الذكي
- نصائح استراتيجية مخصصة
- تحليل الأداء والتوصيات
- حل مشاكل إدارة الوقت

### 📧 التقارير الآلية
- تقارير أسبوعية عبر البريد الإلكتروني
- ملخص التقدم والتحديات
- الخطط المستقبلية

## 🛠️ المتطلبات التقنية

- **Node.js**: 18.0 أو أحدث
- **npm/pnpm**: لإدارة الحزم
- **MySQL/TiDB**: قاعدة البيانات
- **React 19**: الواجهة الأمامية
- **Express 4**: الخادم الخلفي
- **tRPC 11**: اتصال آمن بين الأمام والخلف

## 🚀 البدء السريع

### 1. استنساخ المستودع
```bash
git clone https://github.com/hasanalibrahim/founders-focus-dashboard.git
cd founders-focus-dashboard
```

### 2. تثبيت الحزم
```bash
pnpm install
```

### 3. إعداد متغيرات البيئة
```bash
cp .env.example .env.local
```

ثم عدّل الملف بمعلومات قاعدة البيانات والمفاتيح المطلوبة.

### 4. إعداد قاعدة البيانات
```bash
pnpm db:push
```

### 5. تشغيل الخادم الإنمائي
```bash
pnpm dev
```

سيكون التطبيق متاحاً على `http://localhost:3000`

## 📁 هيكل المشروع

```
├── client/                    # الواجهة الأمامية (React)
│   ├── src/
│   │   ├── pages/            # صفحات التطبيق
│   │   ├── components/       # المكونات المعاد استخدامها
│   │   ├── lib/              # المكتبات والأدوات
│   │   └── index.css         # الأنماط العامة
│   └── public/               # الملفات الثابتة
├── server/                    # الخادم الخلفي (Express)
│   ├── routers/              # مسارات tRPC
│   ├── db.ts                 # دوال قاعدة البيانات
│   └── _core/                # الملفات الأساسية
├── drizzle/                  # مخطط قاعدة البيانات
│   └── schema.ts             # تعريف الجداول
└── shared/                   # الملفات المشتركة

```

## 🔐 المصادقة

يستخدم التطبيق نظام OAuth المدمج مع دعم كامل للمصادقة الآمنة. جميع البيانات محمية وآمنة.

## 📝 الترخيص

هذا المشروع مرخص تحت رخصة MIT. يمكنك استخدامه وتطويره بحرية.

## 👨‍💻 المطور

تم تطوير هذا المشروع بواسطة **Future Shield** - شركة متخصصة في تطوير البرمجيات والحلول الرقمية.

**الموقع**: [www.thefutureshield.com](http://www.thefutureshield.com)

## 📞 التواصل والدعم

للأسئلة والدعم، يرجى التواصل عبر:
- البريد الإلكتروني: support@thefutureshield.com
- الموقع: www.thefutureshield.com

## 🤝 المساهمة

نرحب بالمساهمات! يرجى:
1. عمل Fork للمشروع
2. إنشاء فرع جديد (`git checkout -b feature/AmazingFeature`)
3. Commit التغييرات (`git commit -m 'Add some AmazingFeature'`)
4. Push إلى الفرع (`git push origin feature/AmazingFeature`)
5. فتح Pull Request

## 🗺️ خارطة الطريق

### المرحلة التالية
- [ ] تطبيق نظام تتبع الوقت المتقدم
- [ ] فرض حد الـ 3 مشاريع النشطة
- [ ] المساعد الذكي بـ AI
- [ ] التقارير الآلية عبر البريد
- [ ] تطبيق الهاتف المحمول
- [ ] التكامل مع Slack و Teams

---

<div align="center">

**صُنع بـ ❤️ من قبل Future Shield**

جميع الحقوق محفوظة © 2026

</div>

</div>
